local function getHighestPlayer()
    local resultId = db.storeQuery("SELECT `name` FROM `players` ORDER BY `level` DESC, `experience` DESC LIMIT 1")
    if not resultId then
        return false
    end

    return result.getDataString(resultId, "name")
end

local config = {
    interval = 5,
    effect = CONST_ME_YELLOW_RINGS
}

local function sendEffectTopPlayer(cid)
    local player = Player(cid)
    if not player then
        return true
    end

    player:getPosition():sendMagicEffect(config.effect)
    addEvent(sendEffectTopPlayer, config.interval * 1000, cid)
    return true
end

function onLogin(player)
    if player:getName() ~= getHighestPlayer() then
        return true
    end

    sendEffectTopPlayer(player:getId())
    return true
end