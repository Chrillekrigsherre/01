function onStatsChange(cid, attacker, type, combat, value)
        if((not attacker) or (not isPlayer(attacker)) or (not isCreature(attacker))) then
                return true
        end
local item = getPlayerSlotItem(COSNT_SLOT_ARROW)
local damage = value+ (value*0.20)
    if item and item.itemid == 1111  then
       if(type == STATSCHANGE_HEALTHLOSS or type == STATSCHANGE_MANALOSS) then
            doTargetCombatHealth(attacker, cid, type, -damage , -damage , CONST_ME_NONE)
        end
end
    return true
    end