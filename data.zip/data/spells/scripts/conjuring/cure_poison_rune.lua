function onCastSpell(creature, variant)
	return creature:conjureItem(2260, 2266, 1)
end
