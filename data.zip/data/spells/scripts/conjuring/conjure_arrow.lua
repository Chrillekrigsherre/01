function onCastSpell(creature, variant)
	return creature:conjureItem(0, 2544, 10, CONST_ME_MAGIC_BLUE)
end
