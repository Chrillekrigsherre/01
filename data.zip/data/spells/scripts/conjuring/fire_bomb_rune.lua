function onCastSpell(creature, variant)
	return creature:conjureItem(2260, 2305, 2)
end
