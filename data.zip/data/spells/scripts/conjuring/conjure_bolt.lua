function onCastSpell(creature, variant)
	return creature:conjureItem(0, 2543, 5, CONST_ME_MAGIC_BLUE)
end
