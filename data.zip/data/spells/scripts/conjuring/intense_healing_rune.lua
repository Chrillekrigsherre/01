function onCastSpell(creature, variant)
	return creature:conjureItem(2260, 2265, 1)
end
