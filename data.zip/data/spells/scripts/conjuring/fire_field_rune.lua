function onCastSpell(creature, variant)
	return creature:conjureItem(2260, 2301, 3)
end
