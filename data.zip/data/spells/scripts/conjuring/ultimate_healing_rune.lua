function onCastSpell(creature, variant)
	return creature:conjureItem(2260, 2273, 1)
end
