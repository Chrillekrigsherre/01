function onCastSpell(creature, variant)
	return creature:conjureItem(2260, 2292, 10)
end
