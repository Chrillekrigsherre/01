createFunctions(MonsterType) -- creates get/set functions for MonsterType
createFunctions(Spell) -- creates get/set functions for Spell
